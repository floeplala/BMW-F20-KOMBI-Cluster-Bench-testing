#include <ArduinoUnitTests.h>
#include <Arduino.h>

unittest(basic_sanity_check) {
    assertTrue(true);
}

unittest_main()
