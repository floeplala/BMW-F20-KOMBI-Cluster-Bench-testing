
#pragma once

#include "fl/raster_sparse.h"

namespace fl {

using XYRaster = XYRasterU8Sparse;

}